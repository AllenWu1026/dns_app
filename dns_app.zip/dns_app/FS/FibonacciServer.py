from flask import Flask, request, jsonify

app = Flask(__name__)

# Placeholder for registered data
registered_data = None

# This route handles HTTP PUT requests at /register
@app.route('/register', methods=['PUT'])
def register():
    global registered_data

    # Get JSON data from the request body
    data = request.get_json()

    # Validate the required fields in the JSON data
    if 'hostname' in data and 'ip' in data and 'as_ip' in data and 'as_port' in data:
        registered_data = data
        return jsonify({"message": "Registration successful"}, 201)
    else:
        return jsonify({"error": "Missing or incorrect parameters"}, 400)

# This route handles HTTP GET requests at /fibonacci
@app.route('/fibonacci', methods=['GET'])
def get_fibonacci():
    number = request.args.get('number')

    # Check if the number is an integer
    try:
        number = int(number)
    except ValueError:
        return jsonify({"error": "Invalid sequence number format"}, 400)

    # Calculate Fibonacci and return as JSON
    result = calculate_fibonacci(number)
    return jsonify({"result": result}, 200)

def calculate_fibonacci(n):
    # Function to calculate Fibonacci numbers
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        a, b = 0, 1
        for _ in range(2, n + 1):
            a, b = b, a + b
        return b

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=9090)
