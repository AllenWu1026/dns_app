import socket

# Create a UDP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Bind the socket to the desired address and port (port 53533 as specified)
server_address = ('0.0.0.0', 53533)
server_socket.bind(server_address)

# Dictionary to store DNS records (in-memory database)
dns_records = {}

while True:
    data, client_address = server_socket.recvfrom(1024)
    
    # Parse the incoming DNS request (e.g., TYPE=A NAME=fibonacci.com)
    request = data.decode('utf-8').strip()
    
    # Split the request into parts based on spaces
    request_parts = request.split(' ')
    
    if len(request_parts) == 4 and request_parts[0] == 'TYPE=A' and request_parts[1] == 'NAME':
        # Registration request
        hostname = request_parts[2]
        ip_address = request_parts[3]
        
        # Store the DNS record in the dictionary
        dns_records[hostname] = ip_address
        
        # Respond with a success message
        response = f"Registration successful for {hostname} with IP {ip_address}"
        server_socket.sendto(response.encode('utf-8'), client_address)
    elif len(request_parts) == 2 and request_parts[0] == 'TYPE=A' and request_parts[1] == 'NAME':
        # DNS query
        hostname = request_parts[1]
        
        if hostname in dns_records:
            # If the hostname exists in the records, respond with the IP address
            ip_address = dns_records[hostname]
            response = f"TYPE=A NAME={hostname} VALUE={ip_address} TTL=10"
        else:
            # If the hostname is not found, respond with a failure message
            response = f"DNS record for {hostname} not found"
        
        server_socket.sendto(response.encode('utf-8'), client_address)
