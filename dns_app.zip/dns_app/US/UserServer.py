from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

# This route handles HTTP GET requests at /fibonacci
@app.route('/fibonacci', methods=['GET'])
def get_fibonacci():
    # Get parameters from the query string
    hostname = request.args.get('hostname')
    fs_port = request.args.get('fs_port')
    number = request.args.get('number')
    as_ip = request.args.get('as_ip')
    as_port = request.args.get('as_port')

    # Check if any of the required parameters is missing
    if not (hostname and fs_port and number and as_ip and as_port):
        return jsonify({"error": "Missing parameters"}, 400)  # HTTP 400 Bad Request

    # Make a request to the Authoritative Server (AS) to get the IP address
    try:
        response = requests.get(f"http://{as_ip}:{as_port}/resolve?hostname={hostname}")
        if response.status_code != 200:
            return jsonify({"error": "Failed to resolve hostname"}, 500)  # Handle DNS resolution failure

        # Assuming FS server is running on the provided hostname and fs_port
        fs_url = f"http://{response.json()['ip']}:{fs_port}/fibonacci?number={number}"

        # Make a request to the Fibonacci Server (FS)
        response = requests.get(fs_url)

        if response.status_code == 200:
            return response.text  # HTTP 200 OK with the Fibonacci number as the response
        else:
            return jsonify({"error": "Failed to get Fibonacci number from FS"}, 500)  # Handle FS server failure
    except Exception as e:
        return jsonify({"error": str(e)}, 500)  # Handle unexpected errors

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)

